/**************************************************************************************************************************** */
/*****    GLOBAL VARIABLES                                                                                **** */
/**************************************************************************************************************************** */
var $j = jQuery.noConflict();
var __cardSiteURL = "";
var __cardBackPic = "/SiteAssets/Program/picture/play_backcard.jpg"
var __cardFirstSelected = -1;
var __cardSecondSelected = false;
var __cardTotalCardPicks = 0;

/**************************************************************************************************************************** */
/*****    CARD DECK STRUCTURE                                                                                **** */
/**************************************************************************************************************************** */
var __cardDeckFaces = [
    "/SiteAssets/Program/picture/card25.jpg",
    "/SiteAssets/Program/picture/card50.jpg",
    "/SiteAssets/Program/picture/card75.jpg",
    "/SiteAssets/Program/picture/card100.jpg",
    "/SiteAssets/Program/picture/cardstop.jpg",
    "/SiteAssets/Program/picture/cardspeed.jpg",
    "/SiteAssets/Program/picture/cardspare.jpg",
    "/SiteAssets/Program/picture/cardgo.jpg",
    "/SiteAssets/Program/picture/cardrepair.jpg",
    "/SiteAssets/Program/picture/cardflat.jpg",
    "/SiteAssets/Program/picture/cardlimit.jpg",
    "/SiteAssets/Program/picture/cardcrash.jpg",
];


/**************************************************************************************************************************** */
/*****    APPLICATION STARTS HERE                                                                                        **** */
/**************************************************************************************************************************** */
$j(document).ready(function()  {
    __cardSiteURL = _spPageContextInfo.webAbsoluteUrl;
    __cardBackPic = __cardSiteURL + __cardBackPic;
    var headerHTML = "<button type='button' class='btn btn-success btn-lg btn-block' id='cardsSaveBtn'>Play</button>";
    $j("#matchMeHeaderContent").html(headerHTML);
    $j("#cardsSaveBtn").click( function() {
        MATCHINGGAME.setupNewGame();
        $j("#cardsSaveBtn").hide();
    });
});

MATCHINGGAME = {
    name: 'MATCHINGGAME',
    pageHTML: "",
    gameDeal: [],
    winningDialog: "",
    setupNewGame: function() {
        MATCHINGGAME.gameDeal = [];
        MATCHINGGAME.pageHTML= "";
        __cardTotalCardPicks = 0;

        var endRowTag = "";
        MATCHINGGAME.pageHTML += "<div class='grid'>";
        for (var i = 0; i < 24; i++) {
            var faceIdx = i/2;
            if ((i % 2) != 0) {
                faceIdx = (i - 1)/2;
            }
            var shuffleIdx = parseInt(Math.random()*1000000);
            var thisCard = { "id": i, 
                                "matchId": faceIdx, 
                                "shuffleID": shuffleIdx, 
                                "facePic": __cardSiteURL + __cardDeckFaces[faceIdx], 
                                "faceShowing": false, 
                                "cardMatched": false };
            MATCHINGGAME.gameDeal.push(thisCard);
        }
        MATCHINGGAME.gameDeal = MATCHINGGAME.gameDeal.sort(function(objOne, objTwo) {
            var matchOne = objOne.shuffleID;
            var matchTwo = objTwo.shuffleID;
            return ((matchOne < matchTwo) ? -1 : ((matchOne > matchTwo) ? 1 : 0));
        });
        for (var j = 0; j < MATCHINGGAME.gameDeal.length; j++) {
            MATCHINGGAME.pageHTML += "<div class='col-lg-2 col-md-4 col-sm-6 col-xs-12 flipplacrholder' >";
            MATCHINGGAME.pageHTML += "<div class='flip-container' id='cardCard" + j + "' onclick='MATCHINGGAME.flipCard(" + j + ");'><div class='flipper'>";
            MATCHINGGAME.pageHTML += "<div class='back'><img src='" + MATCHINGGAME.gameDeal[j].facePic + "'></div>";
            MATCHINGGAME.pageHTML += "<div class='front'><img src='" + __cardBackPic + "'></div>";
            MATCHINGGAME.pageHTML += "</div></div>";
            MATCHINGGAME.pageHTML += "</div>";            
        }
        MATCHINGGAME.pageHTML += "</div>";
        MATCHINGGAME.pageHTML += MATCHINGGAME.dialogSuccessHTML();
        $j("#matchMeMainContent").html(MATCHINGGAME.pageHTML);     
        $j("cardDialog-winmessage").hide();

        MATCHINGGAME.winningDialog = $j("#cardDialog-winmessage").dialog({
            modal: true,
            open: function() {
               $j("#cardDivDialogFlips").html("You found all the matches in " + __cardTotalCardPicks + " moves.");
            },
            buttons: {
              Ok: function() {
                $j( this ).dialog( "close" );
              }
            }
        });
        MATCHINGGAME.winningDialog.dialog("close");
    },
    flipCard: function(cardID) {
        
        //  only have 2 cards flipped over
        if (__cardSecondSelected) {
            return false;
        }

        //  dont 'double flip' the same card
        if (MATCHINGGAME.gameDeal[cardID].faceShowing == true) {
            return false;
        }

        document.querySelector("#cardCard" + cardID).classList.toggle("flip");
        __cardTotalCardPicks += 1;
        if (__cardFirstSelected == -1)  {
            
            //  only one card is flipped
            __cardFirstSelected = cardID;
            MATCHINGGAME.gameDeal[cardID].faceShowing = true;
            return false;

        }  else  {
            
            __cardSecondSelected = true;

            //  see if there is a matching card
            if (MATCHINGGAME.gameDeal[cardID].matchId == MATCHINGGAME.gameDeal[__cardFirstSelected].matchId)  {
                MATCHINGGAME.gameDeal[cardID].cardMatched = true;
                MATCHINGGAME.gameDeal[__cardFirstSelected].cardMatched = true;
                var options = {};
                $j("#cardCard" + cardID).hide( "explode", options, 1000, null );
                $j("#cardCard" + __cardFirstSelected).hide( "explode", options, 1000, null );
                __cardSecondSelected = false;
                __cardFirstSelected = -1;
                
                ///  check to see if there are any cards left
                var gameOver = true;
                for (var i = 0; i < MATCHINGGAME.gameDeal.length; i++) {
                    if (!MATCHINGGAME.gameDeal[i].cardMatched) {
                        gameOver = false;
                    }
                }
                if (gameOver) {
                    MATCHINGGAME.winningDialog.dialog("open");
                    __cardTotalCardPicks = 0;
                    $j("#cardsSaveBtn").show();
                }
                return false;
            }

            //  cards do not match - flip the 2 card over
            var resetCardsSelected = function() {
                MATCHINGGAME.gameDeal[cardID].faceShowing = false;
                MATCHINGGAME.gameDeal[__cardFirstSelected].faceShowing = false;
                document.querySelector("#cardCard" + cardID).classList.toggle("flip");
                document.querySelector("#cardCard" + __cardFirstSelected).classList.toggle("flip");                 
                __cardSecondSelected = false;
                __cardFirstSelected = -1;
            }
            setTimeout(resetCardsSelected, 1350);
        }
    },
    dialogSuccessHTML: function() {
        var dialogHTML = "";
        dialogHTML += '<div id="cardDialog-winmessage" title="WINNER !!!!!">';
        dialogHTML += '<table>';
        dialogHTML += '<tr>';
        dialogHTML += '<td>';
        dialogHTML += '<img src="' + __cardSiteURL +  '/SiteAssets/Program/picture/cardwinner.jpg" width="100px" ></img>';
        dialogHTML += '</td>';
        dialogHTML += '<td>';
        dialogHTML += '<div id="cardDivDialogFlips">You found all the matches in <label id="cardDialogFlips"></label> moves.</div>';
        dialogHTML += '</td>';
        dialogHTML += '</tr>';
        dialogHTML += '</table>';
        dialogHTML += '</div>';

        return dialogHTML;
    },
}
